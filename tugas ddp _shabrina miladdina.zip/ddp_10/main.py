print("========== Profile ===========")
nama = "Shabrina Miladdina"
nim = ("0110124016")
rombel = "Sistem Informasi 12"
matakuliah = "Dasar-Dasar Pemprograman"
print(f"Nama : {nama}")
print(f"Nim : {nim}")
print(f"Rombel : {rombel}")
print(f"Tugas Mata Kuliah : {matakuliah}")

import hitung, luas_bangun_datar, luas_bangun_ruang

# Modul Hitung
print("========== Modul Hitung ===========")
hitung.tambah(6, 8)
hitung.kurang(2024, 2006)
hitung.kali(5, 10)
hitung.bagi(40, 2)
hitung.pangkat(6, 4)

# Modul Luas Bangun Datar
print("========== Modul Luas Bangun Datar ===========")
luas_bangun_datar.luas_persegi (8)
luas_bangun_datar.luas_persegi_panjang (13, 9)
luas_bangun_datar.luas_segitiga (10, 6)
luas_bangun_datar.luas_lingkaran (14)
luas_bangun_datar.luas_jajargenjang (7, 8)

# Modul Luas Bangun Ruang
print("========== Modul Luas Bangun Ruang ===========")
luas_bangun_ruang.luas_kubus(6)
luas_bangun_ruang.luas_balok(3, 4, 5)
luas_bangun_ruang.luas_limas_segitiga(9, 7)
luas_bangun_ruang.luas_prisma(9, 5)
luas_bangun_ruang.luas_tabung(22/7, 14)