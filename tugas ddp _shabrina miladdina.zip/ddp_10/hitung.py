# Membuat Model Hitung
import math

def tambah(bilangan1, bilangan2) :
    hasil = bilangan1 + bilangan2
    print(f"Hasil dari Penjumlahan {bilangan1} + {bilangan2} = {hasil}")
   
def kurang(bilangan1, bilangan2) :
    hasil = bilangan1 - bilangan2
    print(f"Hasil dari Pengurangan {bilangan1} - {bilangan2} = {hasil}")   
   
def kali(bilangan1, bilangan2) :
    hasil = bilangan1 * bilangan2
    print(f"Hasil dari Perkalian {bilangan1} x {bilangan2} = {hasil}")

def bagi(bilangan1, bilangan2) :
    hasil = bilangan1 / bilangan2
    print(f"Hasil dari Pembagian {bilangan1} / {bilangan2} = {hasil}")
    
def pangkat(bilangan1, bilangan2) :
    hasil = bilangan1 ^ bilangan2
    print(f"Hasil dari Pemangkatan {bilangan1} ^ {bilangan2} = {hasil}")
