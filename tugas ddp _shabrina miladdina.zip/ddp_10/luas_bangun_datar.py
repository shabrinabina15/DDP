# Membuat Modul untuk Menghitung Luas Bangun Datar
import math

def luas_persegi(sisi):
  hitung = sisi * sisi
  print(f"Luas persegi adalah {hitung}")

def luas_persegi_panjang(p, l):
  hitung = p * l
  print(f"Luas persegi panjang adalah {hitung}")

def luas_segitiga(a, t):
  hitung = 1/2 * a * t
  print(f"Luas segitiga adalah {hitung}")

def luas_lingkaran(r):
  hitung = r * 22/7 * r
  print(f"Luas lingkaran adalah {hitung}")

def luas_jajargenjang(alas, tinggi):
  hitung = alas * tinggi
  print(f"Luas jajargenjang adalah {hitung}")