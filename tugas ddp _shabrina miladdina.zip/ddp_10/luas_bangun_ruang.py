# Membuat Modul Untuk Menghitung Luas Bangun Datar
import math
def luas_kubus(s):
  hitung = 6 * s ** 2
  print(f"Luas kubus adalah {hitung}")

def luas_balok(p, l, t):
  hitung = 2 * (p * l + p * t + l * t)
  print(f"Luas balok adalah {hitung}")

def luas_limas_segitiga(la, ls):
  hitung = la + ls
  print(f"Luas limas segitiga adalah {hitung}")

def luas_prisma(la, ls):
  hitung = ( 2 * la) + ls
  print(f"Luas prisma adalah {hitung}")

def luas_tabung(pi, r):
  hitung = 2 * pi * r ** 2
  print(f"Luas tabung adalah {hitung}")